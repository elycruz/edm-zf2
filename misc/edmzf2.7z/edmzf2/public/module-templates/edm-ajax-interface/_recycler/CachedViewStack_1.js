define([
    'common/ui/navigation/ViewStack',
    'common/ui/navigation/CachedView'
    ], 
    function (ViewStack, CachedView) {
        
        /**
         * Cached View Stack
         * @param options
         * @return default
         */
        function CachedViewStack (options) 
        {
            options.itemConstructor = 
            options.itemConstructor || CachedView;
            ViewStack.apply(this, options);
        }

        // Alias prototype
        CachedViewStack.fn = CachedViewStack.prototype;
        
        // Exetnd CachedViewStack's prototype with ViewStack's prototype
        $.extend(true, CachedViewStack.fn, ViewStack.fn);
        
        return CachedViewStack;
    });