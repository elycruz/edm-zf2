define(['view-models/ViewModule'], function(ViewModule) {
    
    /**
     * View Module Stack constructor
     * @param options object optional
     * @return default
     */
    function ViewModuleStack (options) 
    {
        var self = this,
        
        viewModules;
        
        self.viewModules = [];
        
        self.viewElm = null;
        
        if (empty(options)) {
            return;
        }
            
        if (!empty(options.viewModules)) {
            viewModules = options.viewModules;
                
            delete options.viewModules;
            self.addViewModules(viewModules);
        }
        
        $.extend(true, self, options);
    }
    
    /**
     * Alias for View Module Stack's prototype
     * @var ViewModuleStack.prototype
     */
    ViewModuleStack.fn = ViewModuleStack.prototype;
    
    /**
     * Adds view modules to the stack
     * @param viewModules array
     * @throws Error if viewModules not array
     * @return array
     */
    ViewModuleStack.fn.addViewModules = function (viewModules)
    {
        var self = this, viewModule;
        
        viewModules = typeof viewModules === 'function' ? viewModules() : viewModules;
        
        if (!Array.isArray(viewModules)) {
            throw {
                message: 'ViewModuleStack.addViewModules requires an array ' +
            'or an observable array.'
            };
        }
        
        viewModules.forEach(function(viewModule, i) {
            // Set viewModule list order
            if (empty(viewModule.listOrder)) {
                viewModule.listOrder = i;
            }
            
            // Add viewModule item
            self.addViewModule(viewModule);
        });
    };
    
    /**
     * Adds a view module to the stack
     * @param viewModule object 
     * @param constructor function optional
     */
    ViewModuleStack.fn.addViewModule = function (viewModule, constructor) 
    {
        var self = this,
        
        Construct = constructor || ViewModule;
        
        viewModule = new Construct(viewModule);
        
        self.viewModules.push(viewModule);
    };
    
    /**
     * Returns array of view modules
     * @return array 
     */
    ViewModuleStack.fn.getViewModules = function () 
    {
        return this.viewModules;
    };
    
    /**
     * Returns an empty object or attributes if specified
     * @return mixed object 
     */
    ViewModuleStack.fn.getAttribs = function () 
    {
        return this.attribs || {};
    };
    
    // Return our View Module Stack
    return ViewModuleStack;
});