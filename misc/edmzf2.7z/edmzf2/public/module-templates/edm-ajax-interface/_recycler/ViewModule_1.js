define(function () {
    
    /**
     * Constructor for View Module
     * @return default
     */
    function ViewModule (options) {
        
        
    }
    
    /**
     * Alias for View Module's prototype
     * @var object default ViewModule.prototype
     */
    ViewModule.fn = ViewModule.prototype;
    
    // Return our View Module
    return ViewModule;
})