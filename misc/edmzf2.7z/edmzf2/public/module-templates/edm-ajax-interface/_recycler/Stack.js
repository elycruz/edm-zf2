define(['knockout', 'es5'], function () 
    {
        'use strict';
    
        function Stack(options) 
        {
            var self = this;
            self.items = [];
        
            /**
         * Item Constructor
         * @var mixed string | constructor | other
         */
            self.itemConstructor = null;
        
            if (!empty(options) && options.hasOwnProperty('items')) {
                self.tmpItems = options.items;
                self.addItems(self.tmpItems);
                delete options.items;
                delete self.tmpItems;
            
                // Extend self with options
                $.extend(self, options);
            }
        
        }
    
        Stack.fn = Stack.prototype;
    
        Stack.fn.addItem = function (item) 
        {
            var self = this;
        
            if (item instanceof self.itemConstructor === false && 
                self.itemConstructor !== null) {
                self.items.push(new self.itemConstructor(item));
            }
            else if (!empty(item)) {
                self.items.push(item);
            }
        };

        Stack.fn.addItems = function (items) 
        {
            var self = this, item;
            if (!Array.isArray(items)) {
                throw new Error('Stack.addItems expects parameter 1 to be an ' + 
                    ' parameter received is of type ' + (typeof items));
            }
            items.forEach(function (item) {
                self.addItem(item);
            });
        };
    
        Stack.fn.removeItemsBy = function (key, value) {
            this.items.filter(function (data) { 
                var retVal = false;
                if (data.hasOwnProperty(key)) {
                    retVal = data[key] === value;
                }
                return retVal;
            });
        }
    
        /**
        * Filters array and returns items with a key of value
        * @return array
        */
        Stack.fn.findItemsBy = function (key, value) {
            this.items.filter(function (data) { 
                var retVal = false;
                if (data.hasOwnProperty(key)) {
                    retVal = data[key] === value;
                }
                return retVal;
            });
        };
    
        return Stack;
    
    }); // define