define(function () {
    'use strict';
    
    function Registry () {}
    
    Registry.fn = Registry.prototype;
    
    /**
     * Gets a Registry key
     * @return mixed default null
     */
    Registry.fn.get = function (key) {
        var retVal = null;
        if (Registry.hasOwnProperty(key)) {
            retVal = Registry[key];
        }
        return retVal;
    };
    
    /**
     * Sets a key in the Registry
     * @param key string
     * @param value mixed
     */
    Registry.fn.set = function (key, value) {
        Registry[key] = value;
    };
    
    /**
     * Checks whether registry has key
     * @return boolean
     */
    Registry.fn.hasKey = function (key) {
        return Registry.hasOwnProperty(key);
    };
    
    return Registry;
    
});