define(function () {
    
    function HelloWorld (options) {
        
        var self = this
        
        ;
        
        self.defaultOptions = {
        
        };
        
        $.extend(self, self.defaultOptions, options);
        
        self.init = function () {
            trace('HelloWorld');
        };
    }
    
    var F = HelloWorld;
    
    F.fn = F.prototype;
    
    return F;

});

