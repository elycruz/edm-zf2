define([
    'knockout', 
    'view-module/Registry',
    'view-models/mvc/view/ViewStack', 
    'text!../../../tmpls.html',
    'depend!jquery-ui[jquery]',
    'depend!amplify[jquery]',
    'jquery'
    ], 
    function(ko, Registry, ViewStack, tmpls) {
        
        /**
         * Creates (a) namespace(s) within an object
         * @param ns_string <string>
         * @param extendObj <object> not required
         * @return object 
         */
        exports.namespace = function (ns_string, extendObj) {
            var parts = ns_string.split('.'),
            parent = extendObj || exports,
            i;

            if (parts[0] === 'exports') {
                parts = parts.slice(1);
            }

            for (i = 0; i < parts.length; i += 1) {
                if (typeof parent[parts[i]] === 'undefined') {
                    parent[parts[i]] = {};
                }
                parent = parent[parts[i]];
            }

            return parent;
        };

        // Instantiate Registry in exports variable
        exports.Registry = new Registry();
        
        // Put history on exports variable
        exports.history = window.History;
        
        // Put amplify on exports
        exports.publish = amplify.publish;
        exports.subscribe = amplify.subscribe;
        exports.unpublish = amplify.unpublish;
        
        // Put amplify storage mechanism in exports
        exports.storage = amplify.storage;
        
        // Append top level templates
        $('body').eq(0).append(tmpls);

        /**
         * Main view element for view stack and left col view stack
         * @var jquery element
         */
        var mainView = $('#main'),
        viewStack,
            
        /**
         * Main nav
         * @var jquery item
         */
        mainNav = $('#wrapper > nav').eq(0);
        
        /**
        * Main menu view stack
        * @var view-models/mvc/view/ViewStack
        */
        viewStack = new ViewStack({
            ulAttribs: {
                'class' : 'horiz-menu-left menu grid_16'
            },
            views: [
            {
                route: '#!/design-page',
                htmlSrc: 'text!view-template/design-page/index.html',
                tmplsSrc: 'text!view-template/design-page/tmpls.html',
                module: 'view-module/Test',
                clickFunction: 'changeCurrView',
                label: 'Dashboard'
            },
            //            {
            //                route: '#!/dashboard',
            //                htmlSrc: 'text!view-template/dashboard/index.html',
            //                label: 'Dashboard'
            //            },
            {
                route: '#!/content',
                //htmlSrc: 'text!view-template/index.html',
                label: 'Content',
                ulAttribs: {
                    'class': 'vert-menu-left'
                },
                clickFunction: 'changeCurrView',
                views: [
                {
                    route: '#!/post',
                    htmlSrc: 'text!view-template/post/index.html',
                    attribs: {
                        'class': 'first' 
                    },
                    label: 'Posts',
                    clickFunction: 'changeCurrView'
                },
                {
                    route: '#!/post/category',
                    htmlSrc: 'text!view-template/post-category/index.html',
                    label: 'Category',
                    clickFunction: 'changeCurrView'
                },

                {
                    route: '#!/post/tag',
                    htmlSrc: 'text!view-template/post-tag/index.html',
                    attribs: {
                        'class': 'last' 
                    },
                    label: 'Tag',
                    clickFunction: 'changeCurrView'
                }]
            }],
            viewElm: mainView
        });
        
        // Apply ko bindings
        ko.applyBindings(viewStack, mainNav.get(0));
        
        // Load the first view
        viewStack.changeCurrView(viewStack.getViews()[0]);
        
        // Make drop down menus
        $( 'li ul', mainNav ).each( function() {
            $(this).css('display','none');
            var p = $(this).parent();
            p.hover(function() {
                var ul = p.find( 'ul' );
                //ul.fadeIn( 'fast' ).show();
                ul.slideDown('fast');
            },
            function() {
                var ul = p.find( 'ul' );
                //ul.fadeOut( 'fast' );
                ul.slideUp('fast');
            });
        }); // drop down menus top
        
//    trace(var_dump(History));
//    History.init();
//    History.pushState({state: 'hello', data: 'helloworld'});
//    trace(var_dump(History.getState({state: 'hello', data: 'helloworld'})));
    
}); // define
