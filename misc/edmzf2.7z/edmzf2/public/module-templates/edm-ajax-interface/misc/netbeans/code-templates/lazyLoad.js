F.fn.get${cursor} = function () {
    if (empty(this.${cursor})) {
        this.${cursor} = app.serviceFactory.get(${cursor});
    }
    return this.${cursor};
};