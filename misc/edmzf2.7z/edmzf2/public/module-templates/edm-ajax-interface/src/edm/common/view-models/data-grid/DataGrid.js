define([
    'knockout', 
    'common/ui/HtmlElement',
    'common/view-models/helper/TemplateLoadHelper',
    'common/data/Collection',
    'text!common/view-models/data-grid/data-grid-tmpls.html'
    ], 
    function (ko, HtmlElement, TemplateLoadHelper, Collection) {
    
        'use strict';
    
        function DataGridCell (options) {
            this.visible = ko.observable(true);
            this.alias = 'column-alias';
            this.value = 'Sample value';
            if (options.visible) {
                this.visible(options.visible);
                delete options.visible;
            }
            HtmlElement.apply(this, [options]);
        }
    
        DataGridCell.fn = DataGridCell.prototype;
    
        $.extend(DataGridCell.fn, HtmlElement.fn);
    
        DataGridCell.fn.hide = function () {
            this.visible(false);
        };
    
        DataGridCell.fn.show = function () {
            this.visible(true);
        };
    
        // -------------------------------------------
    
        function DataGridRow (options) {
            var self = this;
            options.itemConstructor = !empty(options) && 
            !empty(options.itemConstructor) ? 
            options.itemConstructor : DataGridCell;
            Collection.apply(self, [options]);
        }
    
        // -------------------------------------------
    
        function DataGridColumn (data) {
            this.label = 'Label';
            DataGridCell.apply(this, [data]);
        }
    
        DataGridColumn.fn = DataGridColumn.prototype;
    
        $.extend(DataGridColumn.fn, DataGridCell.fn);
    
        // -------------------------------------------
    
        function DataGridItem (data) {
            var self = this;
            $.extend(self, data);
            self.getValue = function (key) {
                if (typeof key === 'function') {
                    key(self._listOrder, self);
                }
            };
        }
    
        // -------------------------------------------
    
        /**
     * Data Grid View Model
     * @param options object default null
     */
        function DataGrid (options) {
            var self = this,
            emptyOptions;
        
            self.rows = new Collection({
                itemConstructor: DataGridRow
            });
        
            self.columns = new Collection({
                itemConstructor: DataGridColumn
            });
        
            self.headerText = 'Sample header text';
        
            self.footer = 'Sample footer';
            
            emptyOptions = empty(options);
        
            // Add data if necessary
            if (!emptyOptions && !empty(options.data)) {
                self.rows.addItems(options.data);
//                delete options.data;
            }
        
            if (!emptyOptions && !empty(options.rows)) {
                self.rows.addItems(options.rows);
//                delete options.data;
            }
        
            // Add columns if necessary
            if (!emptyOptions && !empty(options.columns)) {
                self.columns.addItems(options.columns);
//                delete options.columns;
            }

            // Extend this with options from outside
            if (!emptyOptions) {
                $.extend(self, options);
            }
        
            if (self.tmplsLoaded === false) {
                self.loadTmplsFromConfig(self.tmplsSrcConfig);
            }
            
            this.init = function () {};
        }
    
        DataGrid.fn = DataGrid.prototype;
    
        DataGrid.fn.tmplsLoaded = false;

        DataGrid.fn.tmplsSrcConfig = {
            tmplsSrc: 'text!common/view-models/data-grid/data-grid-tmpls.html',
            ids: [
            'table-tmpl',
            'thead-headerText-tmpl',
            'thead-columns-tmpl',
            'tbody-tmpl'            
            ]
        };
                
        DataGrid.fn.toggleColumn = function (index) {
            this.columns[index].hide();
        };
    
        DataGrid.fn.setHeaderText = function (str) {
            this.headerText(str);
        };
    
        DataGrid.fn.loadTmplsFromConfig = function (config) {
            config = config || DataGrid.fn.tmplsSrcConfig;
            TemplateLoadHelper.fn.loadFromConfig(config, DataGrid, this, 'init');
        };
    
        return DataGrid;
    
    }); // define