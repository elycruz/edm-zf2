define(['knockout'], function (ko) 
{
    function HtmlElement (options) {
        var self = this;
        $.extend(true, self, options);
        if (typeof self.attribs !== 'function') {
            self.attribs = ko.observable(self.attribs);
        }
    }
    
    HtmlElement.fn = HtmlElement.prototype;

    HtmlElement.fn.getText = function () {
        return this.text;
    };
    
    HtmlElement.fn.setText = function (text) {
        this.text = text;
    };

    HtmlElement.fn.getAttribs = function () {
        return this.attribs();
    };
    
    HtmlElement.fn.getAttribsObsv = function () {
        return this.attribs;
    };
    
    HtmlElement.fn.getAttrib = function (key) {
        var self = this;
        return self.attribs().key;
    };
    
    HtmlElement.fn.setAttribs = function (attribs) {
        var self = this;
        this.attribs(attribs);
    };
    
    HtmlElement.fn.setAttrib = function (key, value) {
        var self = this;
        self.attribs().key = value;
    };
    
    HtmlElement.fn.hide = function () {};
    HtmlElement.fn.show = function () {};
    HtmlElement.fn.disable = function () {};
    HtmlElement.fn.enable = function () {};
    
    return HtmlElement;
    
});