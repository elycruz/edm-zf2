define([
    'knockout',
    'controllers/index/LoginViewModel'
], function (ko, LoginViewModel) {
    
    function IndexController (options) {
        var self = this;

        self.options = {
            loginViewModel: new LoginViewModel()
        };
        
        self.init = function () {
            self.$element = $('#index');
            $.extend(self, self.options, options);
            ko.applyBindings(self.loginViewModel, self.$element.get(0));
        };
    }
    
    return IndexController;

});

