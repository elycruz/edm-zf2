define([
    'common/view-models/helper/TemplateLoadHelper',
    'common/view-models/data-grid/DataGrid',
    'text!common/view-models/data-grid/data-grid-tmpls.html'
], function (TemplateLoadHelper, DataGrid, dataGridTmpls) {
    var body = $('body');
    body.append(dataGridTmpls);
});