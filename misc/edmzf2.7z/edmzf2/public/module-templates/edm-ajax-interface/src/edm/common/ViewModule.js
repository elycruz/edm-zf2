define([
    'knockout',
    'common/ui/HtmlElement'
], function (ko, HtmlElement) {
    
    function ViewModule (options) {
        
        var self = this;
        
        self.options = {
            header: null,
            title: null,
            footer: null,
            content: null
        };
        
        $.extend(self.options, options);
        
        HtmlElement.apply(this, [self.options]);
    }
    
    ViewModule.fn = ViewModule.prototype = new HtmlElement();
    
    return ViewModule;

});

