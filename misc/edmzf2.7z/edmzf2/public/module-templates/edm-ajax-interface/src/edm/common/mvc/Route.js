define(function () {
    function StaticRoute (options) {
        var self = this;
        $.extend(self, options);
    }
    
    return StaticRoute;
});