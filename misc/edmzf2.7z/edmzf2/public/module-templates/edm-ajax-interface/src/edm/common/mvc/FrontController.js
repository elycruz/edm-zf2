define(function () {
    function FrontController (options) {
        var self = this;
        $.extend(self, options);
    }
    
    return FrontController;
});