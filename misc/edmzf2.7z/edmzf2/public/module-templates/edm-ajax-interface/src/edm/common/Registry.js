define(function () {
    function Registry () {}

    Registry.fn = Registry.prototype;

    Registry.fn.get = function (key) {
        return this.hasKey(key) ? this[key] : null;
    };

    Registry.fn.set = function (key, value) {
        this[key] = value;
    };

    Registry.fn.hasKey = function (key) {
        return this.hasOwnProperty(key);
    };

    return Registry;
});