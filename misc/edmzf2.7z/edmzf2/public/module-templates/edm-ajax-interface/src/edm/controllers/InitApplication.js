define([
    'knockout', 
    'common/Registry', 
    'common/ui/navigation/ViewStack', 
    'text!../../../tmpls.html',
    'depend!jquery-ui[jquery]',
    'depend!amplify[jquery]',
    'common/ui/TemplateList',
    'jquery'
    ], 
    function(ko, Registry, ViewStack, tmpls) {
        var body = $('body').eq(0),
        
        /**
         * Main view element for view stack and left col view stack
         * @var jquery element
         */
        mainView = $('#main'),
        
        /**
         * Main nav
         * @var jquery item
         */
        mainNav = $('#wrapper > nav').eq(0),

        /**
        * Main menu view stack
        * @var view-models/mvc/view/ViewStack
        */
        viewStack;
        
        /**
         * Creates (a) namespace(s) within an object
         * @param ns_string <string>
         * @param extendObj <object> not required
         * @return object 
         */
        app.namespace = function (ns_string, extendObj) {
            var parts = ns_string.split('.'),
            parent = extendObj || app,
            i;

            if (parts[0] === 'app') {
                parts = parts.slice(1);
            }

            for (i = 0; i < parts.length; i += 1) {
                if (typeof parent[parts[i]] === 'undefined') {
                    parent[parts[i]] = {};
                }
                parent = parent[parts[i]];
            }

            return parent;
        };

        // Instantiate Registry in app variable
        app.Registry = new Registry();
        
        // Put history on app variable
        app.history = window.History;
        
        // Put amplify on app
        app.publish = amplify.publish;
        app.subscribe = amplify.subscribe;
        app.unpublish = amplify.unpublish;
        
        // Put amplify storage mechanism in app
        app.storage = amplify.storage;
        
        // Append top level templates
        body.append(tmpls);
        
        // View Stack
        viewStack = new ViewStack({
            ulAttribs: {
                'class' : 'horiz-menu-left menu grid_16'
            },
            collection: [
//            {
//                route: '#!/index',
//                htmlSrc: 'text!controllers/index/index.html',
//                controller: 'controllers/index/IndexController',
//                clickFunction: 'changeCurrentView',
//                label: 'Index'
//            },
            {
                route: '#!/design-page',
                htmlSrc: 'text!controllers/design-page/index.html',
                tmplsSrc: 'text!controllers/design-page/tmpls.html',
                tmplIds: [
                    'table-tmpl',
                    'thead-header-txt-tmpl',
                    'thead-columns-tmpl',
                    'tbody-tmpl'
                ],
                controller: 'controllers/design-page/DesignPage',
                clickFunction: 'changeCurrentView',
                label: 'Design Page'
            },
            {
                route: '#!/content',
                //htmlSrc: 'text!view-template/index.html',
                label: 'Content',
                ulAttribs: {
                    'class': 'vert-menu-left'
                },
                clickFunction: 'changeCurrentView',
                collection: [
                {
                    route: '#!/post',
                    htmlSrc: 'text!controllers/post/index.html',
                    attribs: {
                        'class': 'first' 
                    },
                    label: 'Posts',
                    clickFunction: 'changeCurrentView'
                },
                {
                    route: '#!/post/category',
                    htmlSrc: 'text!controllers/post-category/index.html',
                    label: 'Category',
                    clickFunction: 'changeCurrentView'
                },

                {
                    route: '#!/post/tag',
                    htmlSrc: 'text!controllers/post-tag/index.html',
                    attribs: {
                        'class': 'last' 
                    },
                    label: 'Tag',
                    clickFunction: 'changeCurrentView'
                }]
            }],
            $viewElement: mainView
        });
        
        // Apply ko bindings
        ko.applyBindings(viewStack, mainNav.get(0));
        
        // Load the first view
        viewStack.setCurrentView(viewStack.getViews()[0]);
        
        // Make drop down menus
        $( 'li ul', mainNav ).each( function() {
            $(this).css('display','none');
            var p = $(this).parent();
            p.hover(function() {
                var ul = p.find( 'ul' );
                //ul.fadeIn( 'fast' ).show();
                ul.slideDown('fast');
            },
            function() {
                var ul = p.find( 'ul' );
                //ul.fadeOut( 'fast' );
                ul.slideUp('fast');
            });
        }); // drop down menus top
        
    //    trace(var_dump(History));
    //    History.init();
    //    History.pushState({state: 'hello', data: 'helloworld'});
    //    trace(var_dump(History.getState({state: 'hello', data: 'helloworld'})));
    
    }); // define
