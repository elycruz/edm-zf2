define(function () {
    
    function ActionStack (options) {
        Collection.apply(this, [options]);
    }
    
    ActionStack.fn = ActionStack.prototype;
    
    $.extend(ActionStack.fn, Collection.fn);
    
    return ActionStack;

});

