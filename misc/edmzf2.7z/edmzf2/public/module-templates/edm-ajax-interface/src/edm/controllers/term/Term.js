define([
    
    'jquery', 
    'knockout' 
//    'view-models/DataGrid', 
//    'view-models/HtmlElement'
    
], function ($, ko) {
    
    var loc = window.location;
    
    return function Term () 
    {
        var 
        
        // Endpoint
        endpoint = loc.protocol +'//edmzf2/edm-admin',
        
        // Actions
        indexAction,
        createAction,
        updateAction,
        deleteAction,
        elm = $('#term');
            
        createAction = function () {
            var $elm = $('#term-create');
            $.get(endpoint + '/term/create', function (data) {
                $('.content', $elm).eq(0).append(data);
            });
        };
        
        indexAction = function () {
            $.get(endpoint + '/term/index', {
                format: 'json'
            }, function (data) {
                
                // Make data grid
                var table = new DataGrid({
                    headerText: 'Term index',
                    columns: [
                    {
                        label: '',
                        alias: 'indexLabel'
                    },
                    {
                        label: 'Name',
                        alias: 'name'
                    },
                    {
                        label: 'Alias',
                        alias: 'alias'
                    },
                    {
                        label: 'Term Group Alias',
                        alias: 'term_group_alias'
                    }],
                    data: data.results
                });
                
                var test = new HtmlElement({
                    attribs: {
                        id: 'this-is-just-a-test',
                        'class': 'm10px'
                    }
                });
                
                trace(test);
                
                // Apply bindings
                ko.applyBindings(table, $('#term-index').get(0));
                
            }); // get
            
        }; // index
        
        updateAction = function () {
            $.get(endpoint + '/term/update', {
                format: 'html'
            }, function (data) {
                trace(data);
            });
        };
        
        deleteAction = function () {
            $.get(endpoint + '/term/update', {
                format: 'html'
            }, function (data) {
                trace(data);
            });
        };
            
//        indexAction();
        createAction();
        
    } // Term
    
}); // define