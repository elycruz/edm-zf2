define(function () {
    
    function Base (options) {
        $.extend(this, options);
    }
    
    var F = Base;
    
    F.fn = F.prototype;
    
    return F;

});

