Edm Cms - Ajax Interface

- Pre alpha stage
    - This project is not yet ready for production use and is still in the
        design stage

- Preliminaries for now

Edm ajax interface is an ajax interface that will be 
built using KnockoutJs, Jquery, Jquery-ui, and RequireJs
to provide a snappy interface for cms engines (mainly edm cms).

