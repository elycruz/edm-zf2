<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Edm_Form_Element_SelectCategory
 *
 * @author ElyDeLaCruz
 */
class Edm_Form_Element_SelectCategory
 extends Zend_Form_Element_Select
{
    /**
     * Use formSelect view helper by default
     * @var string
     */
    public $helper = 'formSelectCategory';
}
