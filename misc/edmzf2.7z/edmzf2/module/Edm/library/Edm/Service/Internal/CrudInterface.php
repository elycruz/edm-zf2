<?php
/**
 * @author ElyDeLaCruz
 */
interface Edm_Service_Internal_CrudInterface
{
//    public function create(array $data);
    public function read(array $options = null);
//    public function update(array $data);
//    public function delete(array $data);
}