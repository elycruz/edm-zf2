<?php

/*
 */

/**
 *
 * @author ElyDeLaCruz
 */
interface Edm_Service_Internal_TermTaxonomyAccess {
    /**
     * @return Edm_Service_Internal_AbstractCrudService
     */
    public function getTermTaxService();
    
}
