<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of AddressService
 *
 * @author ElyDeLaCruz
 */
class AddressService {
    //put your code here
}
