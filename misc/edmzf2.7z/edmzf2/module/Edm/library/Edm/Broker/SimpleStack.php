<?php

/**
 *
 * @author ElyDeLaCruz
 */
interface Edm_Broker_SimpleStack {
    public function normalizeName($name);
}