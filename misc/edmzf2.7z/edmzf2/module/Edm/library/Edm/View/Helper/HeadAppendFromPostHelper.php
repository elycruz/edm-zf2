<?php

/*
 */

/**
 * Description of HeadAppendFromPostHelper
 *
 * @author ElyDeLaCruz
 */
class HeadAppendFromPostHelper {
    //put your code here
}