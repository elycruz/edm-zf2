<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Edm for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Edm\Controller;

use Zend\Mvc\Controller\AbstractActionController,
    Zend\View\Model\ViewModel,
    Zend\View\Model\JsonModel,
    Edm\Model\Term,
    Edm\Model\TermTable,
    Edm\Form\TermForm;

class TermController extends AbstractActionController {

    protected $termModel;

    public function indexAction() {
        $view = new JsonModel();
        $model = $this->getTermModel();
        $rslt = $model->select();
        $view->rslts = $rslt;
//        $view->setTerminal(true);
        return $view;
    }

    public function createAction() {
        $view = new ViewModel();
        $view->setTerminal(true);
        $view->form = new TermForm();

        $request = $this->getRequest();
        if (!$request->isPost()) {
            return $view;
        }

        $term = new Term();
        $view->form->setInputFilter($term->getInputFilter());

        if (!$view->form->isValid()) {
            return $view;
        }

        $term->exchangeArray($form->getData());
        $this->getTermModel()->create($term);
        $view->success = true;
        $view->message = 'Term created successfuly!';
        return $view;
    }

    public function fooAction() {
        // This shows the :controller and :action parameters in default route
        // are working when you browse to /module-specific-root/TermTaxonomy/foo
        return array();
    }

    /**
     * Gets our Term model
     * @return Edm\Model\TermModel
     */
    public function getTermModel() {
        if (empty($this->termModel)) {
            $this->termModel = $this->getServiceLocator()->get('Edm\Model\TermTable');
        }
        return $this->termModel;
    }

}
