<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Edm\Form;

use Zend\Form\Form;

/**
 * Description of EdmForm
 *
 * @author ElyDeLaCruz
 */
class EdmForm extends Form {
}
