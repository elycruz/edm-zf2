<?php

abstract class AbstractModel {

    protected $primaryModel;
    
    public function getPrimaryModel() {
        return $this->primaryModel;
    }

    public function setPrimaryModel($primaryModel) {
        $this->primaryModel = $primaryModel;
    }
        
    public function getBy(array $by) {
        $rowSet = $this->primaryModel->select($by);
        $row = $rowSet->current();
        if (!$row) {
            $i = 0;
            foreach ($by as $key => $val) {
                $msg .= $i != count($by) ? ', ' : '';
                $msg .= $key . ' => ' . $val;
                $i += 1;
            }
            throw new \Exception('Couldn\'t find row by your criteria: ' . $msg);
        }
        return $row;
    }
}

