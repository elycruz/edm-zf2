<?php
namespace Edm\Model;

use Zend\Db\TableGateway\TableGateway,
        Edm\Model\AbstractModel,
        Edm\Model\Term;

class TermModel extends AbstractModel {
    
    protected $primaryTable;
    
    public function __construct(TableGateway $primaryTableGateway) {
        $this->primaryTable = $primaryTableGateway;
    }
    
    public function create (Term $item) {
        return $this->primaryTable->insert($item->toArray());
    }
    
    public function read () {
        return $this->primaryTable->select();
    }
    
    public function getById ($term_id) {
        return $this->getBy(array('term_id' => $term_id));
    }
    
    public function update (Term $item) {
        return $this->primaryTable->update($item, array('term_id' => $item->term_id));
    }
    
    public function delete (Term $item) {
        return $this->primaryTable->delete(array('term_id' => $item->term_id));
    }
}
