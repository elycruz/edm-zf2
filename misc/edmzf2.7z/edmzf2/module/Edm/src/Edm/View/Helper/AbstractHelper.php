<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Edm\View\Helper;
use Zend\View\Helper\AbstractHelper as AbstractViewHelper;

/**
 * Description of AbstractViewHelper
 *
 * @author ElyDeLaCruz
 */
class AbstractHelper extends AbstractViewHelper {
    //put your code here
}
