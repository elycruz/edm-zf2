Sample, Index module for use with the ZF2 MVC layer.
